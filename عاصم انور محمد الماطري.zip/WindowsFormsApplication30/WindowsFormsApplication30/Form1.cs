﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication30
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
            enabled(false);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           textBox2.TextChanged += textBox1_TextChanged;
             textBox3.ReadOnly = true;
             this.Text = " الة حاسبة بسيطة ";
             textBox2.KeyPress+= textBox1_KeyPress;
        }


public void isnumber(KeyPressEventArgs e)
{
if ((e.KeyChar < '0'|| e.KeyChar > ':')&&(e.KeyChar!=8))
{
e.Handled = true;
}
}
public void enabled(bool f)
{
    btndiv.Enabled =btnmul.Enabled =btnsub.Enabled = btnadd.Enabled = f;

}
public void operation(double n1,double n2, string op)
{
switch(op)
{
case "+":textBox3.Text = (n1 + n2).ToString();
textBox3.BackColor = Color.White;
break;
case "-":textBox3.Text = (n1 - n2).ToString(); textBox3.BackColor = Color.White; break;
case "*": textBox3.Text = (n1 * n2).ToString(); textBox3.BackColor = Color.White; break;
case "/":if (n2 != 0) {
textBox3.Text = (n1 / n2).ToString(); textBox3.BackColor = Color.White;
}
else
MessageBox.Show("لا يمكن القسمه على صفر", "تحذير ", MessageBoxButtons.YesNoCancel,
MessageBoxIcon.Warning, MessageBoxDefaultButton.Button3);
break;
default:
textBox3.BackColor = Color.Black;
MessageBox.Show(" العمليه المدخله غلط","تحذير ",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Warning,
MessageBoxDefaultButton.Button3);
break;
}}

private void textBox1_TextChanged(object sender, EventArgs e)
{
    bool f = (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "");
    enabled(f);
}




private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
{
    isnumber(e);
}



private void btnadd_Click(object sender, EventArgs e)
{
    operation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "+");
}

private void btnsub_Click(object sender, EventArgs e)
{
    operation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "-");
}

private void btnmul_Click(object sender, EventArgs e)
{
    operation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "*");
}



private void btndiv_Click_1(object sender, EventArgs e)
{
    operation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "/");
}


private void button5_Click_1(object sender, EventArgs e)
{
    this.Close();
}

private void button6_Click_1(object sender, EventArgs e)
{
    textBox1.Clear();
    textBox2.Clear();
    textBox3.Clear();
}





    }
}
