﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace المحاضرة_الثامنة
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtall_length.Text = txtall_txt.Text.Trim().Length.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtall_txt.SelectedText.Length > 0)
            {
                txtaselect_length.Text = txtall_txt.SelectionLength.ToString();
            }
            else
            {
                MessageBox.Show("قم بتحديد النص");
                txtaselect_length.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] strword = txtall_txt.Text.Trim().Split(' ');
            txtnum_word.Text = (strword.Length - 1).ToString();

        }

        private void button_Click(object sender, EventArgs e)
        {
            if (txtall_txt.SelectionLength > 0)
            {
                txtall_txt.SelectedText = "";
            }
            else
                MessageBox.Show("قم بتحديد نص");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtall_txt.SelectionLength = 0;
        }
        string myselectedtext="";
        private void button6_Click(object sender, EventArgs e)
        {
            if (txtall_txt.SelectedText.Length > 0)
            { myselectedtext = txtall_txt.SelectedText; }
            else
                MessageBox.Show("لايوجد نص محدد");

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (txtall_txt.SelectedText.Length > 0)
            {
                txtall_txt.SelectedText = null;
            }
            else
                MessageBox.Show("لايوجد نص محدد");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            txtcopypast.Text += myselectedtext.Trim();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            txtall_txt.Undo();
            txtcopypast.Undo();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtall_txt.Clear();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i < txtall_txt.Text.Length; i++)
            {
                if (txtall_txt.Text[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());

        }

        private void button10_Click(object sender, EventArgs e)
        {

            int x = 0;
            for (int i = 0; i < txtall_txt.SelectedText.Length; i++)
            {
                if (txtall_txt.SelectedText[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (txtall_txt.SelectionLength > 0)
            {
                if (txtall_txt.Text.Trim() != "")
                {
                    txtall_txt.SelectedText = txtedite.Text;
                }
                else
                    MessageBox.Show("ادخل نص جديد");

            }
            else
                MessageBox.Show("حدد النص المراد تعديله");
            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_txt.Text.IndexOf(txtsearch.Text, 0);
                if (index > -1)
                {
                    txtall_txt.SelectionStart = index;
                    txtall_txt.SelectionLength = txtsearch.Text.Length;
                    txtall_txt.Focus();
                }
                else
                    MessageBox.Show("ليس موجود");
            }
            else

            {MessageBox.Show("ادخل النص المراد البحث عنه");
                txtsearch.Focus();
        }










    }

        private void button13_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_txt.Text.IndexOf(txtsearch.Text, txtall_txt.SelectionStart + txtall_txt.SelectionLength);
                if (index > -1)
                {
                    txtall_txt.Focus();
                    txtall_txt.Select(index, txtsearch.Text.Length);
                }
                else
                    MessageBox.Show("ليس موجود");
            }
            else
                MessageBox.Show("ادخل النص المراد البحث عنه");
            txtsearch.Focus();
            txtsearch.Focus();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_txt.Text.LastIndexOf(txtsearch.Text, txtall_txt.SelectionStart + txtall_txt.SelectionLength);
                if (index > -1)
                {
                    txtall_txt.Focus();
                    txtall_txt.Select(index, txtsearch.Text.Length);
                }
                else
                    MessageBox.Show("ليس موجود");
            }
            else
                MessageBox.Show("ادخل النص المراد البحث عنه");
            txtsearch.Focus();
            txtsearch.Focus();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string s = txtall_txt.SelectedText;
            char[] ch = s.ToCharArray();
            for (int i = 0; i < ch.Length; i++)
                listBox1.Items.Add(ch[i]);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string[] s =txtall_txt.SelectedText.Split(' ');
            for (int i = 0; i < s.Length; i++)
            {
                listBox2.Items.Add(s[i]);
            }
        }

        }








}