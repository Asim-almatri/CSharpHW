﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_Najm
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        frmAddStudent AddStudent;
        private void إظافةطالبToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (AddStudent == null || AddStudent.IsDisposed)
            {
                AddStudent = new frmAddStudent();
                AddStudent.Show();
            }
            else
            {
                AddStudent.Show();
                AddStudent.Focus();
            }
        }
        frmShowStudents ShowStudents;
        private void عرصالطلابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(ShowStudents == null || ShowStudents.IsDisposed)
            {
                ShowStudents = new frmShowStudents();
                ShowStudents.Show();
            }
            else
            {
                ShowStudents.Show();
                ShowStudents.Focus();
            }
        }

        private void إغلاقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = Application.OpenForms.Count;
            if (n > 1)
                Application.OpenForms[n - 1].Close();
            
            //this.ActiveMdiChild.Close();
        }

        private void إغلاقالكلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = Application.OpenForms.Count;
            while(n>1)
            {
                Application.OpenForms[n-1].Close();
                n--;
            }
            //if(n>1)
            //{
            //    for (int i = n - 1; i >= 1; i++)
            //        Application.OpenForms[i].Close();
            //}
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
