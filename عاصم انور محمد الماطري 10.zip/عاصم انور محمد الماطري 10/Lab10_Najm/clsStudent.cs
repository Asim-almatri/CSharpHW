﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_Najm
{
    public class clsStudent
    {
        private int id;

        private string name;
        private string birthDate;
        private string imagePath;

        public int Id
        {
            get {return id;}
            set {id = value;}
        }

        public string Name
        {
            get {return name;}
            set {name = value;}
        }

        public string BirthDate
        {
            get {return birthDate;}
            set {birthDate = value;}
        }

        public string ImagePath
        {
            get {return imagePath;}
            set {imagePath = value;}
        }
    }
}
