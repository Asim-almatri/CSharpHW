﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_Najm
{
    public partial class frmModifyStudent : Form
    {
        public frmModifyStudent()
        {
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void frmModifyStudent_Load(object sender, EventArgs e)
        {
            LoadStudentData();
        }
       public int index;
        private void LoadStudentData()
        {
            index = frmShowStudents.index;
            numericUpDown1.Value = Convert.ToInt16(frmAddStudent.student[index].Id);
            textBox1.Text = frmAddStudent.student[index].Name;
            dateTimePicker1.Text = frmAddStudent.student[index].BirthDate;
            pictureBox1.Image = Image.FromFile(frmAddStudent.student[index].ImagePath);
        }

        private bool isUpdateImage = false;
        OpenFileDialog openfDlg = new OpenFileDialog();

        private void btnModify_Click(object sender, EventArgs e)
        {
            frmAddStudent.student[index].Id = Convert.ToInt16(numericUpDown1.Value);
            frmAddStudent.student[index].Name = textBox1.Text;
            frmAddStudent.student[index].BirthDate = dateTimePicker1.Text;
            if(isUpdateImage)
            {
                frmAddStudent.student[index].ImagePath = openfDlg.FileName;
            }
            MessageBox.Show("student modified");
            this.Close();
        }

        private void btnChoseImage_Click(object sender, EventArgs e)
        {
            openfDlg.Filter = "images|*.png|images|*.jpg";
            if (openfDlg.ShowDialog()==DialogResult.OK)
            {
                isUpdateImage = true;
                pictureBox1.Image = Image.FromFile(openfDlg.FileName);
            }
        }
    }
}
