﻿namespace Lab10_Najm
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.إدارةباناتالطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ملقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إظافةطالبToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرصالطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إغلاقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إغلاقالكلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إدارةباناتالطلابToolStripMenuItem,
            this.ملقToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(584, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // إدارةباناتالطلابToolStripMenuItem
            // 
            this.إدارةباناتالطلابToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إظافةطالبToolStripMenuItem,
            this.عرصالطلابToolStripMenuItem});
            this.إدارةباناتالطلابToolStripMenuItem.Name = "إدارةباناتالطلابToolStripMenuItem";
            this.إدارةباناتالطلابToolStripMenuItem.Size = new System.Drawing.Size(135, 24);
            this.إدارةباناتالطلابToolStripMenuItem.Text = "إدارة بانات الطلاب";
            // 
            // ملقToolStripMenuItem
            // 
            this.ملقToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إغلاقToolStripMenuItem,
            this.إغلاقالكلToolStripMenuItem});
            this.ملقToolStripMenuItem.Name = "ملقToolStripMenuItem";
            this.ملقToolStripMenuItem.Size = new System.Drawing.Size(50, 24);
            this.ملقToolStripMenuItem.Text = "ملف";
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // إظافةطالبToolStripMenuItem
            // 
            this.إظافةطالبToolStripMenuItem.Name = "إظافةطالبToolStripMenuItem";
            this.إظافةطالبToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.إظافةطالبToolStripMenuItem.Text = "إظافة طالب";
            this.إظافةطالبToolStripMenuItem.Click += new System.EventHandler(this.إظافةطالبToolStripMenuItem_Click);
            // 
            // عرصالطلابToolStripMenuItem
            // 
            this.عرصالطلابToolStripMenuItem.Name = "عرصالطلابToolStripMenuItem";
            this.عرصالطلابToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.عرصالطلابToolStripMenuItem.Text = "عرص الطلاب";
            this.عرصالطلابToolStripMenuItem.Click += new System.EventHandler(this.عرصالطلابToolStripMenuItem_Click);
            // 
            // إغلاقToolStripMenuItem
            // 
            this.إغلاقToolStripMenuItem.Name = "إغلاقToolStripMenuItem";
            this.إغلاقToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.إغلاقToolStripMenuItem.Text = "إغلاق";
            this.إغلاقToolStripMenuItem.Click += new System.EventHandler(this.إغلاقToolStripMenuItem_Click);
            // 
            // إغلاقالكلToolStripMenuItem
            // 
            this.إغلاقالكلToolStripMenuItem.Name = "إغلاقالكلToolStripMenuItem";
            this.إغلاقالكلToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.إغلاقالكلToolStripMenuItem.Text = "إغلاق الكل";
            this.إغلاقالكلToolStripMenuItem.Click += new System.EventHandler(this.إغلاقالكلToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 362);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem إدارةباناتالطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إظافةطالبToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرصالطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ملقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إغلاقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إغلاقالكلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
    }
}