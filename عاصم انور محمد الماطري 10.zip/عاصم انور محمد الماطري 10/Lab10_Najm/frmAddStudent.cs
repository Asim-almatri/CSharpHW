﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_Najm
{
    public partial class frmAddStudent : Form
    {
        public static clsStudent[] student = new clsStudent[100];
        public static int count = 0;
        public frmAddStudent()
        {
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }
        bool ischoiceImage = false;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (count < 100)
            {
                if (ischoiceImage)
                {
                    student[count] = new clsStudent();
                    student[count].Id = Convert.ToInt16(numericUpDown1.Value);
                    student[count].Name = textBox1.Text;
                    student[count].BirthDate = dateTimePicker1.Text;
                    student[count].ImagePath = OpenFDlg.FileName;
                    count++;
                    ischoiceImage = false;
                    pictureBox1.Image = null;
                    textBox1.Text = "";
                    MessageBox.Show("تم إظافة الطالب بنجاح");
                }
                else
                    MessageBox.Show("قم بادخال صورة الطالب");
            }
            else
                MessageBox.Show("تجاوزت الحد المسوح به");
        }
        OpenFileDialog OpenFDlg;
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFDlg = new OpenFileDialog();
            OpenFDlg.Filter = "images|*.png|images|*.jpg";
            if(OpenFDlg.ShowDialog() ==DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(OpenFDlg.FileName);
                ischoiceImage = true;
            }
        }

        private void frmAddStudent_Load(object sender, EventArgs e)
        {

        }
    }
}
