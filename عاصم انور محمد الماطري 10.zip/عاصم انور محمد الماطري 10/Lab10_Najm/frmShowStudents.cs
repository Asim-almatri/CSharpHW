﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_Najm
{
    public partial class frmShowStudents : Form
    {
        public frmShowStudents()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmShowStudents_Load(object sender, EventArgs e)
        {
            LoadStudentsData();

            listBox1.SelectedIndexChanged += findSelectedIndexList;
            listBox2.SelectedIndexChanged += findSelectedIndexList;
            listBox3.SelectedIndexChanged += findSelectedIndexList;
        }
        private void LoadStudentsData()
        {
            for(int i=0;i<frmAddStudent.count;i++)
            {
                listBox1.Items.Add(frmAddStudent.student[i].Id.ToString());
                listBox2.Items.Add(frmAddStudent.student[i].Name.ToString());
                listBox3.Items.Add(frmAddStudent.student[i].BirthDate.ToString());
                pictureBox1.Image = Image.FromFile(frmAddStudent.student[i].ImagePath.ToString());
              //  listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = 0;
            }
        }
        public static int index = -1;
        private void findSelectedIndexList(object sender,EventArgs e)
        {
            if(((ListBox)sender).SelectedIndex != -1)
            {
                index = listBox3.SelectedIndex = listBox2.SelectedIndex = listBox1.SelectedIndex = ((ListBox)sender).SelectedIndex;
                pictureBox1.Image = Image.FromFile(frmAddStudent.student[index].ImagePath);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedItem != null)
            {
                listBox1.Items.Remove(listBox1.SelectedItem);
                listBox2.Items.Remove(listBox2.SelectedItem);
                listBox3.Items.Remove(listBox3.SelectedItem);

                for (int i = index; i < frmAddStudent.count; i++)
                    frmAddStudent.student[i] = frmAddStudent.student[i + 1];
                frmAddStudent.count--;

                if (frmAddStudent.count >= 1)
                {
                    pictureBox1.Image = Image.FromFile(frmAddStudent.student[0].ImagePath);
                    listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = 0;
                }
                else
                    pictureBox1.Image = null;
            }

        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedItem!=null)
            {
                frmModifyStudent modifyst = new frmModifyStudent();
                modifyst.ShowDialog();
                listBox1.Items[index] = frmAddStudent.student[index].Id;
                listBox2.Items[index] = frmAddStudent.student[index].Name;
                listBox3.Items[index] = frmAddStudent.student[index].BirthDate;
                pictureBox1.Image = Image.FromFile(frmAddStudent.student[index].ImagePath);

            }
        }
    }
}
