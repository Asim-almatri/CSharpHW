﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication36
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("ترحيب", "انقر على الواجهه للحصول على الوان مختلفة", MessageBoxButtons.OKCancel);
            this.CenterToParent();
            txt1.Text = "asim";


        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Random r = new Random();
            this.BackColor = Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txt1.Text.Trim() != "")
                txt1.BackColor = Color.Yellow;
            else
                txt1.BackColor = Color.White;

        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.Red;
            button1.BackColor = Color.Yellow;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {

            button1.BackColor = Color.Gray;
            button1.ForeColor = Color.Black;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("مع السلامة");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool isnumber(string s)
        {
            for (int i = 0; i < s.Length; i++)
                if (s[i] >= 48 && s[i] <= 57)
                    return true;
            return false;
        }
        int x = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "" && !isnumber(textBox1.Text))
            {
                txt1.Text += textBox1.Text + "\r\n".ToString();
                textBox1.Focus();
                textBox1.Clear();
            }


        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            txt1.BackColor = Color.Black;
        }
    }

}