﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication36
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
              // btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top - 5); 
            btnplayer.Top -= 5; 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height + 5);
            //  txtplayer.Height += 5; 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height - 5);
            // txtplayer.Height -= 5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top + 5);
            //txtplayer.Top += 5;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            btnplayer.Location = new Point(btnplayer.Left + 5, btnplayer.Top);
            // txtplayer.Left += 5; 
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            btnplayer.Width += 5;
            //txtplayer.Size = new Size(txtplayer.Width+5, txtplayer.Height ); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            btnplayer.Width -= 5;
            // txtplayer.Size = new Size(txtplayer.Width-5 txtplayer.Height )
        }

        private void button7_Click(object sender, EventArgs e)
        {
            btnplayer.Location = new Point(btnplayer.Left - 5, btnplayer.Top);
            // txtplayer.Left -= 5;
        }

        private void button9_Click(object sender, EventArgs e)
        {
             if (checkBox5.Checked)
                 checkBox5.Checked = false;
             else if (checkBox10.Checked)
                 checkBox10.Checked = false;
             else if (checkBox15.Checked)
                 checkBox15.Checked = false;
             else if (checkBox20.Checked)
                 checkBox20.Checked = false;
        }

        private void btnplayer_MouseEnter(object sender, EventArgs e)
        {

        }

        private void button9_MouseEnter(object sender, EventArgs e)
        {
            if (radioButtonup.Checked)
                for (int i = 0; i < Top; i++)
                {
                    if (radioButtondown.Checked)
                    {
                        
    // تحديد قيمة الحركة بناءً على الصناديق الاختيارية المحددة
    int moveIncrement = 0;

    if (checkBox5.Checked)
        moveIncrement = Convert.ToInt32(checkBox5.Text);
    else if (checkBox10.Checked)
        moveIncrement = Convert.ToInt32(checkBox10.Text);
    else if (checkBox15.Checked)
        moveIncrement = Convert.ToInt32(checkBox15.Text);
    else if (checkBox20.Checked)
        moveIncrement = Convert.ToInt32(checkBox20.Text);

    // تحريك زر اللاعب
    btnplayer.Top -= moveIncrement;

    // التأكد من عدم خروج btnplayer عن الحدود
    
}
                }
            else
                if (radioButtondown.Checked)
                {
                    for (int i = 0; i < Top; i++)
                    {
                        Random r = new Random();
                        btnplayer.BackColor= Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255));
                        // تحديد قيمة الحركة بناءً على الصناديق الاختيارية المحددة
                        int moveIncrement = 0;

                        if (checkBox5.Checked)
                            moveIncrement = Convert.ToInt32(checkBox5.Text)-4;
                        else if (checkBox10.Checked)
                            moveIncrement = Convert.ToInt32(checkBox10.Text);
                        else if (checkBox15.Checked)
                            moveIncrement = Convert.ToInt32(checkBox15.Text);
                        else if (checkBox20.Checked)
                            moveIncrement = Convert.ToInt32(checkBox20.Text);

                        // تحريك زر اللاعب
                        btnplayer.Top += moveIncrement;

                        // التأكد من عدم خروج btnplayer عن الحدود
                        if (btnplayer.Top > panel1.Height - btnplayer.Height)
                            btnplayer.Top = 0;
                    }
                }

                    }

        private void btnplayer_Click(object sender, EventArgs e)
        {
            
        }
        }


    }

