﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication36
{
    public partial class Form2 : Form
    {

        string[] a;
        int m =0, i = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            txtadd.Enabled = button1.Enabled = button3.Enabled
               = button2.Enabled = listBox1.Enabled = txtres.Enabled = false;
        }





        private void txtarrnum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
                e.Handled = true;
            if (e.KeyChar == 8)
                e.Handled = false;
        }

        private void txtadd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
                e.Handled = true;
            if (e.KeyChar == 8)
                e.Handled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (i > 0)
            {
            for (int h = 0; h < i; h++)
            { listBox1.Items.Add(a[h]); }
           // listBox1.Items.AddRange(a);// بجي نا نوكت عيمج عقاوم هفوفصملا هزوجحم 

            }
            else
                MessageBox.Show(" القاىمة فارغة ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int b = listBox1.Items.Count;
            if (b > 0)
            {
                for (int h = 1; h <= b; h++)
                    listBox1.Items.Remove(listBox1.Items[0]);

                i = m = 0;
                a = new string[0];
                txtadd.Text = txtarrnum.Text = txtres.Text = " ";
                Form2_Load(null, null);
            }
            else
                MessageBox.Show(" القاىمة فارغة ");
        }

        private void txtarrnum_TextChanged(object sender, EventArgs e)
        {
            bool f = (txtarrnum.Text != "");
            txtadd.Enabled = button1.Enabled = button2.Enabled
            = button3.Enabled = listBox1.Enabled = txtres.Enabled = f;//(txtarrnum.Text != "") 
            listBox1.Items.Clear();
            txtres.Text = "";
        }






        private void button4_Click(object sender, EventArgs e)
        {
            int s = 0;
            if (listBox1.Items.Count > 0)
            {
                for (int h = 0;h<i; h++)
                {
                    s += Convert.ToInt32(a[h]);

                }
                txtres.Text = s.ToString();
            }
            else
                MessageBox.Show("القاىمة فارغة");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtadd.Text.Trim() != "")
            {
                if (i < m)
                {

                    a[i++] = Convert.ToString(txtadd.Text);
                    txtadd.Focus();
                    txtadd.Clear();

                   
                   
                  

                }
                else
                {
                    MessageBox.Show(" تجاوزت حد المصفوفة"); 
                    txtadd.Clear();
                }
            }
            else
            {
                MessageBox.Show(" ادخل الرقم");

            }
        }

        private void txtadd_Leave(object sender, EventArgs e)
        {

           





        }

        private void txtarrnum_Leave(object sender, EventArgs e)
        {
            if (txtarrnum.Text.Trim() != "")
            {
                m = int.Parse(txtarrnum.Text);
                a = new string[m]; i = 0;

            }

        }

      
    }
}
