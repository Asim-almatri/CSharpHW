let cartCount = 0;

function addToCart() {
    cartCount++;
    document.getElementById("cart-count").innerText = cartCount;
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById("cart-items");
    const cartEmptyMessage = document.getElementById("cart-empty-message");

    if (cartCount > 0) {
        cartEmptyMessage.style.display = "none";
        const newItem = document.createElement("li");
        newItem.textContent = `إكسسوار جديد - عدد: ${cartCount}`;
        cartItems.appendChild(newItem);
    } else {
        cartEmptyMessage.style.display = "block";
    }
}
