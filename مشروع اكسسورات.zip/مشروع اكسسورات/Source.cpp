﻿#include<iostream>
#include<string>
using namespace std;

class person
{
public:
	person();
	person(string, string);
	void set_first_name(const string&);
	void set_last_name(const string&);
	void set_full_name(const string&, const string&);
	string get_first_name()const;
	string get_last_name()const;
	void print_first_name()const;
	void print_last_name()const;
	void print_full_name()const;
	void read_full_name();
	~person() {}
protected:
	string firstname;
	string lastname;
	friend istream& operator>>(const istream input, person& object);
	friend ostream& operator<<(ostream output, const person& object);
};// end class person
///////////////////////////////////////////////////
class address
{
protected:
	string city;
	int street_number;
	int zipcode;
	friend istream& operator>>(const istream input, address& object);
	friend ostream& operator<<(ostream output, const address& object);
public:
	address();
	address(string, int, int);

	void set_street_number(const int&);
	void set_city_name(const string&);
	void set_zipcode(const int&);
	void set_all_address(const string&, const  int&, const  int&);

	string get_city_name()const;
	int get_street_number()const;
	int get_zipcode()const;

	void print_city_name()const;
	void print_street_number()const;
	void print_zipcode()const;
	void print_all_address()const;
	void read_all_address();
	~address() {}

};

//member function of datatype
//en class address
////////////////////////////////////////////////////////
class doctor :public person, public address
{
private:
	//address doctor_address;
	int doctor_id;
	string doctor_nationality;
	string doctor_specialty;
public:

	doctor();
	doctor(string, string, int, string, string, string, int, int);

	void set_doctor_id(const int);
	void set_doctor_nationality(const string&);
	void set_doctor_specialty(const string&);
	void set_doctor_informatoin(string, string, const int,
		const string&, const string&,
		string, int, int);
	//void set_doctor_address(string,int,int);




	int get_doctor_id()const;
	string get_doctor_nationality()const;
	string get_doctor_specialty()const;
	//string get_doctor_address()const;

	void print_doctor_id();
	void print_doctor_nationality();
	void print_doctor_specialty();
	// void print_doctor_address();
	void print_all_information_of_doctor();


	void read_doctor_id();
	void read_doctor_nationality();
	void read_doctor_specialty();
	//void read_doctor_address();
	void read_all_information_of_doctor();
	~doctor() {}
};//end class doctor:public person
////////////////////////////////////////////////////////
class bill
{
private:
	int  patient_id;
	float pharmacy_charge;
	float room_charge;
	float doctor_fee;
public:
	bill();
	bill(const int, const float, const float, const float);



	void set_patient_id(const int);
	void set_pharmacy_charge(const float);
	void set_room_charge(const float);
	void set_doctor_fee(const float);
	void set_all_information_for_bill(const int, const float, const float, const float);


	int get_patient_id()const;
	float get_pharmacy_charge()const;
	float get_room_charge()const;
	float get_doctor_fee()const;
	float get_total_charge()const;
	void print_patient_id();
	void print_pharmacy_charge();
	void print_room_charge();
	void print_doctor_fee();
	void print_all_information_of_bill();


	void read_patient_id();
	void read_pharmacy_charge();
	void read_room_charge();
	void read_doctor_fee();
	void read_all_information_of_bill();


};

////////////////////////////////////////////////////////
class date
{
private:
	int day;
	int month;
	int year;
public:
	date();
	date(int, int, int);
	void set_date(int, int, int);
	int get_day()const;
	int get_month()const;
	int get_year()const;
	void print_date()const;
	void read_date();



};
//脟谩脻脥忙脮脟脢//////////////////////////////////////////////////////////////////////
class examination :public date
{
protected:
	person p_name;
	char d_name[15];
	int num_exam;
	char gender[10];
public:
	examination();
	examination(string, string, char*, int, char*, int, int, int);
	void set_all_examination(string, string,
		char*, int, char*, int, int, int);
	void print_all_examination();
	void read_all_examination();
void print_examination();
};
examination::examination() :date(), p_name()
{
	d_name[0] = '\0';
	num_exam = 0;
	gender[0] = '\0';


}
examination::examination(string f, string l, char* dactor_name,
	int id_exam, char* p_gen, int d,
	int m, int y) :p_name(f, l), date(d, m, y)
{
	strcpy(d_name, dactor_name);
	num_exam = id_exam;
	strcpy(gender, p_gen);
}
void examination::set_all_examination(string f, string l,
	char* dactor_name,
	int id_exam, char* p_gen, int d,
	int m, int y)
{
	p_name.person::set_full_name(f, l);
	date::set_date(d, m, y);
	strcpy(d_name, dactor_name);
	num_exam = id_exam;
	strcpy(gender, p_gen);


}
void examination::print_all_examination()
{
	p_name.person::print_full_name();
	date::print_date();
	cout << "dactor name   :" << d_name << endl;
	cout << "patint_gnder  :" << gender << endl;
	cout << "id_examnation  " << num_exam << endl;
}
void examination::print_examination()
{
	//p_name.person::print_full_name();
	//date::print_date();
	cout << "dactor name   :" << d_name << endl;
	cout << "patint_gnder  :" << gender << endl;
	cout << "id_examnation  " << num_exam << endl;
}

void examination::read_all_examination()
{
	p_name.person::read_full_name();
	date::read_date();
	cout << "inter dactor name   :";
	cin >> d_name;
	cout << "inter patint_gnder  :";
	cin >> gender;
	cout << "inter id_examnation  ";
	cin >> num_exam;

}
//脟谩脢脭脦铆脮脟脢//////////////////////////////////////////////////////////////
class diagnosis :public doctor
{
protected:
	date* date_in_out;

	char diag_in[10];
	char diag_out[10];
	//char* str;
public:

	diagnosis() :doctor()
	{
		diag_in[0] = '\0';
		diag_out[0] = '\0';
		date_in_out = new date;
		//date_in_out[1] = new date;
	}
	diagnosis(string f, string l, string cit, int st, int zip, date* d_in_out, char* diag_inn, char* diag_outt)
	{
		set_diagnosis(f, l, cit, st, zip, d_in_out, diag_in, diag_outt);
	}
	void set_diagnosis(string f, string l, string cit, int st, int zip, date* d_in_out, char* diag_inn, char* diag_outt)
	{
		date_in_out = new date[2];
		person::set_full_name(f, l);
		address::set_all_address(cit, st, zip);
		date_in_out = d_in_out;
		strcpy(diag_in, diag_inn);
		strcpy(diag_out, diag_outt);
	}
	void print_data_diagnosis()
	{
		person::print_full_name();
		address::print_all_address();

		for (int i = 0; i < 2; i++)
		{
			if (i == 0)
				cout << "date_in_to_hosptall: ";
			else
				cout << "date_out_from_hospitall:  ";
			date_in_out[i].print_date();

		}
		cout << "diagnosis at inter to hospitall:  " << diag_in << endl;
		cout << "diagnosis at exit from hospitall: " << diag_out << endl;
	}

	void read_data_diagnosis()
	{date_in_out = new date[2];
		person::read_full_name();
		address::read_all_address();

		for (int i = 0; i < 2; i++)
		{
			if (i == 0)
				{
				    cout << "inter date_in_to_hosptall:";
				    date_in_out[i].read_date();
				}
			else
			{

				cout << "inter date_out_from_hospitall : ";
			date_in_out[i].read_date();}

		}
		cout << "inter diagnosis at inter to hospitall:";
		cin>>  diag_in ;
		cout << "diagnosis at exit from hospitall:";
		cin>> diag_out;

	}
};


//class pationt
class patint //:public diagnosis, public  examination
{
	diagnosis diag;
	examination exam;
	int id;
	int age;
public:
	patint() {id = 0; age = 0; }
	patint(int i, diagnosis d, examination e, int ag)
	{
		set_patint_data(i, d,e, ag);

	}


	void set_patint_data(int i, diagnosis d, examination e, int ag)
	{
		id = i;
	diag=d;
	exam=e;
	age = ag;

    }
	void print_data_patint()
	{
		cout << "id_patint :" << id << endl;
		cout<<"________________________________________________\n";
		cout<<"        <<<<<<<<< information of data_diagnosis >>>>>>>"<<endl;
	   diag.print_data_diagnosis();
	   cout<<"________________________________________________\n";
	   cout<<"         <<<<<<<<< information of examination:>>>>>>>>>>>"<<endl;
        exam.print_examination();
		cout << "age_patint :" << age << endl;
	}
};

void get_data(patint &p,examination &e,diagnosis &d)
{
int id;
cout<<"enter id for pationt:   ";
cin>>id;

         cout<<"___________________________________________________________\n";
		cout<<"        <<<<<<<<< insert information of data_diagnosis >>>>>>>"<<endl;
d.read_data_diagnosis();
	   cout<<"___________________________________________ __________________\n";
	   cout<<"         <<<<<<<<<insert information of examination:>>>>>>>>>>>"<<endl;
e.read_all_examination();
int age;
cout<<"enter age of pationt:";
cin>>age;
p.set_patint_data(id, d, e, age);
}
	void print_data(patint &p ,bill &b1)
	{
		p.print_data_patint();
		cout<<"___________________________________________________\n ";
		   cout<<"             <<<<<<<<<enter accounting for pationt>>>>>>>>>>\n";
		b1.print_all_information_of_bill();
	}
//main////////////////////////////////////////////////////////////
int main()
{person o[5];
	patint p1[100];
	bill b1;
	examination e;
	diagnosis d;
	int c=0;
	
	while(true)
	{cout<<"enter 1=read ,2=print 9=finsh "<<endl;
		cin>>c;
	if(c==1)
	{for(int i=0;i<3;i++)
	o[i].read_full_name();
	cout<<endl;`}

	else if(c==2)
		{for(int i=0;i<3;i++)
	o[i].print_full_name();
	 cout<<endl;}
	else if(c==9)
		break;
	else
	cout<<"erro \n";}
	
	//get_data(p1,e,d);
    //b1.read_all_information_of_bill();
    //print_data(p1,b1);

	system("pause");
	return 0;
}

//all mumber function for persontype
person::person()
{
	firstname = " ";
	lastname = " ";
}
person::person(string firstname, string lastname)
{
	this->firstname = firstname;
	this->lastname = lastname;
}
void person::set_first_name(const string& firstname)
{
	this->firstname = firstname;

}
void person::set_last_name(const string& lastname)
{
	this->lastname = lastname;
}
void person::set_full_name(const string& firstname, const string& lastname)
{
	this->firstname = firstname;
	this->lastname = lastname;
}
string person::get_first_name()const
{
	return firstname;
}
string person::get_last_name()const
{
	return lastname;
}

void person::print_first_name()const
{
	cout << "the first name is " << firstname << endl;
}


void person::print_last_name()const
{
	cout << "the last name is " << lastname << endl;
}

void person::print_full_name()const
{
	cout << "the first name is " <<firstname << endl;
	cout << "the last name is "<< lastname << endl;

}

void person::read_full_name()
{
	cout << "enter the first name :";
	cin>> firstname;
	cout << "\nenter the last name :";
	cin>>lastname;

}

istream& operator>>(istream input, person& object)
{
	cout << "enter the first name :";
	input >> object.firstname;

	cout << "\nenter the last name :";
	input >> object.lastname;

return input;}
ostream& operator<<(ostream output, const person& object)
{

	cout << "the first name is ";
	output << object.firstname;

	cout << "\nthe last name is ";
	output << object.lastname;

	return output;
}




//********************************************
//member functoin of billtaupe
bill::bill()
{
	patient_id = 0;
	pharmacy_charge = 0;
	room_charge = 0;
	doctor_fee = 0;
}

bill::bill(int patient_id, float pharmacy_charge, float room_charge, float doctor_fee)
{
	this->patient_id = patient_id;
	this->pharmacy_charge = pharmacy_charge;
	this->room_charge = room_charge;
	this->doctor_fee = doctor_fee;
}


void bill::set_patient_id(const int id)
{
	patient_id = id;
}
void bill::set_pharmacy_charge(const float pharmacy_charge)
{
	this->pharmacy_charge = pharmacy_charge;
}
void bill::set_room_charge(const float room_charge)
{
	this->room_charge = room_charge;
}

void bill::set_doctor_fee(const float doctor_fee)
{
	this->doctor_fee = doctor_fee;
}
void bill::set_all_information_for_bill(int patient_id, float pharmacy_charge, float room_charge, float doctor_fee)
{
	this->patient_id = patient_id;
	this->pharmacy_charge = pharmacy_charge;
	this->room_charge = room_charge;
	this->doctor_fee = doctor_fee;
}



int bill::get_patient_id()const
{
	return patient_id;
}

float bill::get_pharmacy_charge()const
{
	return   pharmacy_charge;
}

float bill::get_room_charge()const
{
	return room_charge;
}

float bill::get_doctor_fee()const
{
	return doctor_fee;
}





void bill::print_patient_id()
{
	cout << "the patient's id is " << patient_id << endl;

}
void bill::print_pharmacy_charge()
{

	cout << "pharmacy_charge  is " << pharmacy_charge << endl;

}
void bill::print_room_charge()
{
	cout << "room_charge  is " << room_charge << endl;
}

void bill::print_doctor_fee()
{

	cout << "doctor_fee  is " << doctor_fee << endl;
}
void bill::print_all_information_of_bill()
{


	cout << "the patient's id is " << patient_id << endl;
	cout << "pharmacy_charge  is " << pharmacy_charge << endl;
	cout << "room_charge  is " << room_charge << endl;
	cout << "doctor_fee  is " << doctor_fee << endl;
}



void bill::read_patient_id()
{
	cout << "enter the patient's id :";
	cin >> patient_id;
}
void bill::read_pharmacy_charge()
{
	cout << "enter the pharmacy_charge :";
	cin >> pharmacy_charge;


}
void bill::read_room_charge()
{

	cout << "enter the room_charge :";
	cin >> room_charge;
}
void bill::read_doctor_fee()
{

	cout << "enter the doctor_fee  :";
	cin >> doctor_fee;
}
void bill::read_all_information_of_bill()
{
	cout << "enter the patient's id :";
	cin >> patient_id;
	cout << "enter the pharmacy_charge :";
	cin >> pharmacy_charge;
	cout << "enter the room_charge :";
	cin >> room_charge;
	cout << "enter the doctor_fee  :";
	cin >> doctor_fee;
}

float bill::get_total_charge()const
{
	return pharmacy_charge + room_charge + doctor_fee;
}
//////****************************!!!
//all mumber function for doctortype

doctor::doctor() : address(), person()
{
	doctor_id = 1;
	doctor_nationality = "no enterd";
	doctor_specialty = "no enterd";

}
doctor::doctor(string fname, string lname, int id, string nationality, string job,
	string city, int street, int zipcode)
	:person(fname, lname), address(city, street, zipcode)
{
	doctor_id = id;
	doctor_nationality = nationality;
	doctor_specialty = job;


}



void doctor::set_doctor_id(const int id)
{
	doctor_id = id;
}
void doctor::set_doctor_nationality(const string& nationality)
{
	doctor_nationality = nationality;
}



void doctor::set_doctor_specialty(const string& specialty)
{
	doctor_specialty = specialty;
}

void doctor::set_doctor_informatoin(string fname, string lname,
	const int id,
	const string& nationality,
	const string& job, string city,
	int street, int zipcode)
{
	set_full_name(fname, lname);
	doctor_id = id;
	doctor_nationality = nationality;
	doctor_specialty = job;
	address::set_all_address(city, street, zipcode);

}



//void doctor::set_doctor_address( string city,int streetnum,int zipcode)
//{doctor_address.set_all_address(city,streetnum,zipcode);}



int doctor::get_doctor_id()const
{
	return doctor_id;
}

string doctor::get_doctor_nationality()const
{
	return  doctor_nationality;
}
string doctor::get_doctor_specialty()const
{
	return doctor_specialty;
}

void doctor::print_doctor_id()
{
	cout << "the doctor's id is " << doctor_id << endl;

}
void doctor::print_doctor_nationality()
{
	cout << "the nationality's is " << doctor_nationality << endl;
}
void doctor::print_doctor_specialty()
{
	cout << "the specialty's  is " << doctor_specialty << endl;

}



void doctor::print_all_information_of_doctor()
{
	person::print_full_name();
	cout << "the doctor's id is " << doctor_id << endl;
	cout << "the doctor's nationality is " << doctor_nationality << endl;
	cout << "the doctor's specialty  is " << doctor_specialty << endl;
	address::print_all_address();

}





void doctor::read_doctor_id()
{
	cout << "enter the doctor's id : ";
	cin >> doctor_id;
}
void doctor::read_doctor_nationality()
{
	cout << "enter the doctor's nationality's  :";
	cin >> doctor_nationality;

}
void doctor::read_doctor_specialty()


{
	cout << "enter the doctor's specialty  :";
	cin >> doctor_specialty;
}

void doctor::read_all_information_of_doctor()
{
	person::read_full_name();
	cout << "enter the doctor's id : ";
	cin >> doctor_id;
	cout << "enter the doctor's nationality's  :";
	cin >> doctor_nationality;
	cout << "enter the doctor's specialty  :";
	cin >> doctor_specialty;
	address::read_all_address();
}

//////****************************!!!
//all mumber function for addresstype
address::address()
{

	city = "no city";
	street_number = 0;
	zipcode = 0;



}
address::address(string city, int streetnum, int zipnum)
{
	this->city = city;
	street_number = streetnum;
	zipcode = zipnum;
}


void address::set_street_number(const int& streetnum)
{
	street_number = streetnum;
}

void address::set_city_name(const string& city)
{
	this->city = city;
}

void address::set_zipcode(const int& zipnum)
{
	zipcode = zipnum;
}



void address::set_all_address(const string& city, const int& streetnum, const int& zipnum)
{
	this->city = city;
	street_number = streetnum;
	zipcode = zipnum;
}

string address::get_city_name()const
{
	return city;
}


int address::get_street_number()const
{
	return street_number;
}

int address::get_zipcode()const
{
	return zipcode;
}

void address::print_city_name()const
{
	cout << "the city's name is " << city << endl;
}


void address::print_street_number()const
{
	cout << "the street number is  " << street_number << endl;
}



void address::print_zipcode()const
{
	cout << "the number of zipcode is  " << zipcode << endl;
}


void address::print_all_address()const
{
	cout << "the street number is " << street_number << endl;
	cout << "the city's name is " << city << endl;
	cout << "the number of zipcode is  " << zipcode << endl;
}

void address::read_all_address()
{
	cout << "enter the city name :";
	cin>> city;
	cout << "enter the street number :";
	cin >> street_number;
	cout << "enter the number of zipcode :";
	cin >> zipcode;


}

istream& operator>>(istream input, address& object)
{
	cout << "enter the city name :";
	input >> object.city;

	cout << "\nenter the street number:";
	input >> object.street_number;
	cout << "enter the number of zipcode :";
	input >> object.zipcode;

return input;}
ostream& operator<<(ostream output, const address& object)
{

	cout << "the city's name is ";
	output << object.city;

	cout << "\nthe street number is ";
	output << object.street_number;
   return output;}



//member function of datatype
date::date()
{
	day = month = year = 0;
}
date::date(int day, int month, int year)
{
	set_date(day, month, year);
}
void date::set_date(int d, int m, int y)
{
	if (d <= 0 || d > 31)
		day = 0;
	else
		day = d;

	if (m <= 0 || m > 12)
		month = 0;
	else
		month = m;

	if (y <= 0)
		year = 0;
	else
		year = y;


}
int date::get_day()const
{
	if (day < 10) {
		cout << "0";
		return day;
	}
	return day;
}
int date::get_month()const
{
	cout << "/";
	if (month < 10) {
		cout << "0";
		return month;
	}
	return month;

}
int date::get_year()const
{
	cout << "/";

	if (year < 10) {
		cout << "0";
		return year;
	}
	return year;
}
void date::print_date()const
{//cout<<"date_of_examination :";
	if (day < 10)
		cout << "0" << day << "/";
	else
		cout << day << "/";
	if (month < 10)
		cout << "0" << month << "/";
	else
		cout << month << "/";
	cout << year << endl;

}
void date::read_date()
{
	cout << "\nenter day :";
	cin >> day;
	cout << "enter month :";
	cin >> month;
	cout << "enter year :";
	cin >> year;
}

