﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace مذاكرة
{
    public partial class Form1 : Form
    {
        private List<Point> snak;
        public Form1()
        {
            
            InitializeComponent();
            snak = new List<Point>();
            snak.Add(new Point(5, 5));
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            n.BackColor = Color.Red;
            n.Location = new Point(50, 50);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = textBox1.Text.IndexOf(textBox3.Text);
            if (index != -1)
            {
                textBox1.SelectionStart = index;
                textBox1.SelectionLength = textBox3.Text.Length;
                textBox1.Focus();
            }
            else
                MessageBox.Show("not found");
        }



        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                string filename = openFileDialog1.FileName;
                Bitmap temp = new Bitmap(filename);
                pictureBox1.BackgroundImage = temp;
            }
        }
        int i = 0;
        int s = 0;
        private void right()
        {
            label1.Left += 3;
            if (label1.Left >= this.Width)
                label1.Left = 0;
        }
        private void lef()
        {
            label1.Left -= 3;
            if (label1.Left <= 0)
                label1.Left = this.Width;
        }
        private void to()
        {
            label1.Top -= 3;
            if (label1.Top <= 0)
                label1.Top = this.Height;
        }
        private void down()
        {
            label1.Top += 3;
            if (label1.Top>=this.Height)
                label1.Top = 0;
        }
       
       
        private void bol()
        {
            Random x = new Random();
            Random y = new Random();
            n.Location=new Point(Convert.ToInt32((x.NextDouble())*this.Left),Convert.ToInt32((y.NextDouble())*this.Top));


        }

        private void snake()
        {
            if ((label1.Left >= n.Left-5&&label1.Left<n.Left+5) && (label1.Top >= n.Top-5&&label1.Top<=n.Top+5))
            {
                label1.Text += "o";
                bol();
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            snake();
            if (s == 1)
                to();
            else if (s == 2)
                down();
            else if (s == 3)
                right();
            else if (s == 4)
                lef();

             //label1.Text = i.ToString();
             //   i++;
             //   if (i > 100)
             //       i = 0;
                  
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void b1_Click(object sender, EventArgs e)
        {
            s = 1;

        }

        private void b2_Click(object sender, EventArgs e)
        {
            s = 2;
        }

        private void b3_Click(object sender, EventArgs e)
        {
            s = 3;
        }

        private void b4_Click(object sender, EventArgs e)
        {
            s = 4;
        }

    }
}