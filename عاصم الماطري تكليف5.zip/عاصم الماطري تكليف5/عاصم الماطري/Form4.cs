﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace مذاكرة
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Bitmap mybitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            //int y;
            //for (int x = 0; x <= 100; x++)
            //{
            //    y = x;
            //    mybitmap.SetPixel(x, y, Color.Blue);
            //    //mybitmap.SetPixel(10, x, Color.Red);
            //}
            //    pictureBox1.Image = mybitmap;
            this.CreateGraphics().DrawRectangle(Pens.Red, 30, 30, 30, 30);
           pictureBox1.CreateGraphics().DrawRectangle(Pens.Red, 30, 30, 30, 30);
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        

       
    }
}
