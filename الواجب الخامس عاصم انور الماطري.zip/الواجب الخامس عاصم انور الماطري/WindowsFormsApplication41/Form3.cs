﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class Form3 : Form
    {
       
        public Form3()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            threadgo = new Thread(go);
            threadgo.Start();
        }
        Thread threadgo;
        void go()
        {
           
           int y= button1.Left;
            for (int i = 0; i <= this.Width; i++)
            {
               
                Invoke((Action)(() => { button1.Left += 10; }));
                if (button1.Left > this.Width - button1.Width - 50)
                {
                    for (int j = 0; j <= this.Width; j++)
                    {
                        Invoke((Action)(() => { button1.Left -= 10; }));
                        if (button1.Left==y)
                        { break; }
                        System.Threading.Thread.Sleep(100);
                    }
                    
                }

                System.Threading.Thread.Sleep(100);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            int y = button2.Top;
            for (int i = 0; i <= this.Width; i++)
            {
           
                button2.Top += 10;
            if (button2.Top > this.Height - button2.Height - 70)
            {
                for (int j = 0; j <= this.Width; j++)
                {
                   
                    if (button2.Top == y)
                    { break; }
                    button2.Top -= 10;
                    System.Threading.Thread.Sleep(100);
                }
               
            }
                
                 System.Threading.Thread.Sleep(100);
                Application.DoEvents();
        }
    }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadgo != null)
                threadgo.Abort();
        }

       

    
        }
        
}
