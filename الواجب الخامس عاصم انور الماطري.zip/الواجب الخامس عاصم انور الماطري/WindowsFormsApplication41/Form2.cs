﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1.Location = new Point(1, 60);
            this.Height = button1.Height + 50;
            this.Width = button1.Left + button1.Width + 20;
            textBox2.KeyPress += textBox1_KeyPress;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9' )&& e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        private void visibl()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            panel1.Visible = true;
            Height = panel1.Height * 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "-";
            panel1.BackColor = Color.Orange;
            visibl();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            label1.Text = "+";
            panel1.BackColor = Color.Gold;
            visibl();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "*";
            panel1.BackColor = Color.Green;
            visibl();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "/";;
            panel1.BackColor = Color.White;
            visibl();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (label1.Text == "-")
            {
                if ((textBox1.Text != " ") && (textBox2.Text != " "))
                { textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) - Convert.ToInt32(textBox2.Text)); }
                else
                    MessageBox.Show("ادخل الرقم");
            }
            else if (label1.Text == "+")
            {
                if ((textBox1.Text != " ") && (textBox2.Text != " "))
                { textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) + Convert.ToInt32(textBox2.Text)); }
                else
                    MessageBox.Show("ادخل الرقم");
            }
            else if (label1.Text == "*")
            {
                if ((textBox1.Text != " ") && (textBox2.Text != " "))
                { textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * Convert.ToInt32(textBox2.Text)); }
                else
                    MessageBox.Show("ادخل الرقم");
            }
            else if (label1.Text == "/")
            {


                if ((textBox1.Text != " ") && (textBox2.Text != " "))
                {
                    if (textBox2.Text != "0")
                    { textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) / Convert.ToInt32(textBox2.Text)); }
                    else
                        MessageBox.Show("لايمكن القسمة على صفر");
                }
                else
                    MessageBox.Show("ادخل الرقم");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2_Load(null, null);
        }
    }
}
